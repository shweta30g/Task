import React from "react";
import CreateTable from "./component/CreateTable";

function App() {
  return (
    <div className="App">
      <CreateTable />
    </div>
  );
}

export default App;
